Here you can find 
- the original (ESPS) annotations of EmoDB: lablaut, labsilb, silb
- the transposed and corrected (Praat) annotations of EmoDB (TextGrid_syll_phrase)

the following errors are known and removed in the Praat annotations
- lablaut: contains 3 files less than there are sounds
- labsilb: contains 42 files less than there are sounds
- silb: 13a01Wb.silb is empty
- silb: 08b09Fd.silb has a double row
- silb: 11b02Ab.silb has three double rows
- silb: 11b02Td.silb has a double row
- silb: 03a04Nc.silb contains no text
- if read in as interval tier into praat, the text of lablaut and labsilb is offset for one interval; also because the endtime is missing, the tier is (much) shorter thean the corresponding sound
- silb causes an error if read into praat, because "#" is missing and rows are too short 
- silb: pause-symbols are missing in 14a04Ed, 14a4Tc and 16a04Tc


The filenames encode:
- two-digit number: speaker id
- letter "a" or "b": sentence type
   - "a": one phrase
   - "b": more complex
- two-digit number: sentence (linguistic content) id
- capital letter: emotion type
   - "A": Angst (fear)
   - "E": Ekel (disgust)
   - "F": Freude (happiness)
   - "L": Langeweile (boredom)
   - "N": Neutral (neutral, lack of obvious emotional content)
   - "T": Trauer (sadness)
   - "W": Wut (anger)
- small letter: recording version
This is part 1 of EmoDB.

The filenames encode:
- two-digit number: speaker id
- letter "a" or "b": sentence type
   - "a": one phrase
   - "b": more complex
- two-digit number: sentence (linguistic content) id
- capital letter: emotion type
   - "A": Angst (fear)
   - "E": Ekel (disgust)
   - "F": Freude (happiness)
   - "L": Langeweile (boredom)
   - "N": Neutral (neutral, lack of obvious emotional content)
   - "T": Trauer (sadness)
   - "W": Wut (anger)
- small letter: recording version